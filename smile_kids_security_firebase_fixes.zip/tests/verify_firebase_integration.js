const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');

console.log('=== Smile Kids Firebase Integration Verification ===\n');

// 1. firebase_config.js
console.log('1. Checking firebase_config.js ...');
const configContent = fs.readFileSync(path.join(ROOT, 'firebase_config.js'), 'utf8');
const fakeWindow = {};
eval(configContent.replace(/window\.SmileKidsFirebase/g, 'fakeWindow.SmileKidsFirebase'));
const fbApi = fakeWindow.SmileKidsFirebase;

if (!fbApi) {
  throw new Error('window.SmileKidsFirebase is not defined in firebase_config.js');
}

const requiredProps = [
  'isConfigured', 'app', 'db', 'auth',
  'initFirestoreListeners', 'saveStudentToFirestore',
  'saveAttendanceToFirestore', 'saveGradeToFirestore',
  'signInWithEmail', 'signOutUser', 'onAuthStateChanged'
];

requiredProps.forEach(prop => {
  if (!(prop in fbApi)) {
    throw new Error(`Missing property/method in SmileKidsFirebase: ${prop}`);
  }
});
console.log('  -> All 11 required properties and methods are present.');
console.log(`  -> isConfigured: ${fbApi.isConfigured}`);

// 2. firestore.rules
console.log('\n2. Checking firestore.rules ...');
const rules = fs.readFileSync(path.join(ROOT, 'firestore.rules'), 'utf8');
if (!rules.includes("rules_version = '2'")) throw new Error("Missing rules_version = '2'");
if (!rules.includes('match /students/{id}')) throw new Error('Missing students rules');
if (!rules.includes('match /attendance/{id}')) throw new Error('Missing attendance rules');
if (!rules.includes('match /grades/{id}')) throw new Error('Missing grades rules');
if (!rules.includes('match /timetables/{id}')) throw new Error('Missing timetables rules');
if (!rules.includes('match /settings/{id}')) throw new Error('Missing settings rules');
if (!rules.includes('match /public_view/{id}')) throw new Error('Missing public_view rules');
if (!rules.includes('match /settings/{id}   { allow read: if isStaff(); allow write: if isAdmin(); }')) {
  throw new Error('Settings write must be restricted to isAdmin()');
}
console.log('  -> Rules v2 syntax and collection rules verified.');

// 3. firebase.json
console.log('\n3. Checking firebase.json ...');
const fbJson = JSON.parse(fs.readFileSync(path.join(ROOT, 'firebase.json'), 'utf8'));
if (fbJson.hosting.public !== '.') throw new Error("Public directory must be '.'");
if (fbJson.hosting.cleanUrls !== true) throw new Error('cleanUrls must be true');
if (fbJson.firestore.rules !== 'firestore.rules') throw new Error('firestore.rules must be linked');
console.log('  -> Hosting and Firestore rules configuration verified.');

// 4. school_sync.js
console.log('\n4. Checking school_sync.js ...');
const syncCode = fs.readFileSync(path.join(ROOT, 'school_sync.js'), 'utf8');
if (!syncCode.includes('window.SmileKidsSync')) throw new Error('Missing SmileKidsSync export');
if (!syncCode.includes('saveGradeToFirestore') || !syncCode.includes('saveAttendanceToFirestore')) {
  throw new Error('Missing Firestore save hooks in school_sync.js');
}
console.log('  -> Confirmed cloud sync queue verified.');

// 5. smile_kids_database.js
console.log('\n5. Checking smile_kids_database.js hooks & fallbacks ...');
const dbCode = fs.readFileSync(path.join(ROOT, 'smile_kids_database.js'), 'utf8');
const checks = [
  { name: '_setupFirebaseSync hook in init', ok: dbCode.includes('this._setupFirebaseSync()') },
  { name: 'Firestore realtime onSnapshot listeners', ok: dbCode.includes('window.SmileKidsFirebase.initFirestoreListeners') },
  { name: 'Firestore saveStudentToFirestore hook', ok: dbCode.includes('saveStudentToFirestore') },
  { name: 'Firestore saveAttendanceToFirestore hook in school_sync.js', ok: syncCode.includes('saveAttendanceToFirestore') },
  { name: 'Firestore saveGradeToFirestore hook in school_sync.js', ok: syncCode.includes('saveGradeToFirestore') },
  { name: 'Firestore batchSaveStudents in firebase_config.js', ok: configContent.includes('batchSaveStudents') },
  { name: 'Offline fallback (localStorage intact)', ok: dbCode.includes('SMILE_KIDS_MASTER_DATABASE_2026_V7') },
  { name: 'Google Drive cloud fallback intact', ok: dbCode.includes('syncToCloud') }
];

checks.forEach(c => {
  if (!c.ok) throw new Error(`Check failed: ${c.name}`);
  console.log(`  -> [PASS] ${c.name}`);
});

console.log('\n======================================================');
console.log('ALL INTEGRATION CHECKS PASSED SUCCESSFULLY!');
console.log('======================================================');
