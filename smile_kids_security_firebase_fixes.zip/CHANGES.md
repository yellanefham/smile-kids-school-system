# Smile Kids School System — Security, Firebase & Link Fixes

Extract this archive into the root of `yellanefham/smile-kids-school-system` to apply all fixes.

## Files Included

1. **`firestore.rules`**
   - Restricted `settings/{id}` writes to `isAdmin()` (teachers can still read).
   - Added strict validation on `public_view/{id}` parent updates: blocks `<` and `>` in `nameAr`/`nameEn`, enforces valid `data:image/(jpeg|png|webp);base64,...` format on `photo`, and bounds `parentUpdatedAt`.
2. **`firebase_config.js`**
   - Fixed duplicate `smilekids_firebase_ready` event dispatch (now fires once in `finally`).
   - Fixed startup race condition by assigning `SmileKidsFirebase.app`, `.db`, `.auth`, and `.isReady` before invoking `loadData()`.
3. **`firebase.json`**
   - Added `X-Content-Type-Options`, `X-Frame-Options`, `Referrer-Policy`, and `Permissions-Policy` security headers.
   - Added `docs/**`, `tests/**`, `README*.md`, `portal_template.html`, and `*.cjs` to `hosting.ignore`.
4. **`.github/workflows/sync_to_gdrive.yml`**
   - Added a file-existence guard for `smile_kids_database.json` and `curl --fail` so the workflow doesn't error out when the legacy JSON file isn't present.
5. **`tests/verify_firebase_integration.js`**
   - Fixed relative paths to point to the repo root (`..`), updated `firestore.rules` assertions to `{id}`, and checked `school_sync.js` instead of deleted migration scripts.
6. **`New_Student_Admission_Form.html`, `Teacher_Portal.html`, `certificate_showcase.html`, `portal_template.html`**
   - Replaced the dev-only `gstatic.com/antigravity/web/dev/tailwindcss.min.js` URL with `https://cdn.tailwindcss.com`.
7. **`Student_Roster_Dashboard.html`, `Smile_Kids_School_Management_System.html`**
   - Added `rel="noopener noreferrer"` to all `target="_blank"` links.

## Recommended Follow-Up Steps
- Deploy the updated rules and hosting config: `firebase deploy --only firestore:rules,hosting`
- Retire `staff_login.html` (or switch it to Firebase Auth) and remove legacy `DEFAULT_TEACHER_PINS` from `Teacher_Portal.html` / `portal_template.html` once all staff use Firebase email/password login.
- Restrict your Firebase Web API key by HTTP referrer in Google Cloud Console.
